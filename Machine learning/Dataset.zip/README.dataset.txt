# E-Waste Detection > 2023-12-08 2:52pm
https://universe.roboflow.com/ewaste-fkqc4/e-waste-detection-nqnkq

Provided by a Roboflow user
License: CC BY 4.0

